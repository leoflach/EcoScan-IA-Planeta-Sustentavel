# EcoScan: Assistente de Reciclagem e Compostagem

EcoScan é um projeto educativo que utiliza inteligência artificial para ajudar as pessoas a descartarem corretamente seus resíduos, promovendo práticas sustentáveis de reciclagem e compostagem.

## Sobre o Projeto

O gerenciamento inadequado de resíduos é um dos maiores desafios ambientais da atualidade. No Brasil, cada pessoa produz em média 1,04 kg de lixo por dia, mas apenas 3% dos resíduos são efetivamente reciclados.

O EcoScan foi desenvolvido para:

- Identificar visualmente diferentes tipos de resíduos
- Fornecer instruções personalizadas para descarte correto
- Conectar usuários a pontos de coleta próximos
- Calcular o impacto ambiental positivo de cada ação
- Sugerir alternativas mais sustentáveis

## Funcionalidades

- **Exemplos Interativos**: Demonstrações de análise para diferentes tipos de resíduos
- **Guia de Reciclagem**: Instruções detalhadas sobre como separar corretamente os resíduos
- **Visualização de Impacto**: Cálculos do benefício ambiental do descarte correto
- **Mapa de Pontos de Coleta**: Visualização de locais para descarte adequado

## Tecnologias Utilizadas

- HTML5, CSS3 e JavaScript
- Bootstrap para design responsivo
- Leaflet para visualização de mapas
- Font Awesome para ícones

## Como Usar

1. Acesse o site: [https://seu-usuario.github.io/ecoscan/](https://seu-usuario.github.io/ecoscan/)
2. Navegue até a seção "Exemplos"
3. Clique em um dos exemplos para ver a análise detalhada
4. Explore o guia de reciclagem para aprender mais sobre descarte correto

## Contribuição

Contribuições são bem-vindas! Se você deseja melhorar o EcoScan, siga estes passos:

1. Faça um fork do repositório
2. Crie uma branch para sua feature (`git checkout -b feature/nova-funcionalidade`)
3. Commit suas mudanças (`git commit -m 'Adiciona nova funcionalidade'`)
4. Push para a branch (`git push origin feature/nova-funcionalidade`)
5. Abra um Pull Request

## Licença

Este projeto está licenciado sob a licença MIT - veja o arquivo LICENSE para detalhes.

## Contato

Para mais informações, entre em contato através do email: contato@ecoscan.exemplo.com
